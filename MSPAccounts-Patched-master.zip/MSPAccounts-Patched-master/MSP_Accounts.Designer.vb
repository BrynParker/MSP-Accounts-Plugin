﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MSP_Accounts_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MSP_Accounts_Form))
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabMyAccount = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblMyWarning = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnMySavePassword = New System.Windows.Forms.Button()
        Me.txtMyUsername = New System.Windows.Forms.TextBox()
        Me.lblNewPassword = New System.Windows.Forms.Label()
        Me.lblMyPrefix = New System.Windows.Forms.Label()
        Me.txtNewPassword = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtMyPassword = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnShowPassword = New System.Windows.Forms.Button()
        Me.tabManageUsers = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ChangeAll = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnAddUser = New System.Windows.Forms.Button()
        Me.LabelPrefix = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.cbUserName = New System.Windows.Forms.ComboBox()
        Me.tabManageLocations = New System.Windows.Forms.TabPage()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnSaveExclusions = New System.Windows.Forms.Button()
        Me.DataGridViewLocations = New System.Windows.Forms.DataGridView()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cbxTACusers = New System.Windows.Forms.ComboBox()
        Me.cbxTAClocations = New System.Windows.Forms.ComboBox()
        Me.lblTACusers = New System.Windows.Forms.Label()
        Me.lblTAClocations = New System.Windows.Forms.Label()
        Me.btnAllLocationsExec = New System.Windows.Forms.Button()
        Me.cbxTACactions = New System.Windows.Forms.ComboBox()
        Me.cbxTACxoverride = New System.Windows.Forms.CheckBox()
        Me.lblTACactions = New System.Windows.Forms.Label()
        Me.tabServiceAccount = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.lblLocalAccountsExclude = New System.Windows.Forms.Label()
        Me.chkLocalAccountsExclude = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblLocalAccountsFlag = New System.Windows.Forms.Label()
        Me.lblLocalAccountsFlagExplain = New System.Windows.Forms.Label()
        Me.btnLocalAccountsFlag = New System.Windows.Forms.Button()
        Me.chkLocalAccountsFlag = New System.Windows.Forms.CheckBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.btnServicePass = New System.Windows.Forms.Button()
        Me.lblServiceAccountPass = New System.Windows.Forms.Label()
        Me.txtServicePass = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblServiceAccount = New System.Windows.Forms.Label()
        Me.cbxServiceAccount = New System.Windows.Forms.ComboBox()
        Me.lblServiceAccountPrefix = New System.Windows.Forms.Label()
        Me.btnServiceAccount = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tabSettings = New System.Windows.Forms.TabPage()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtMinLower = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtMinNumber = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtMinSpecial = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtMinUpper = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnTest = New System.Windows.Forms.Button()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblChangeDaysExplain = New System.Windows.Forms.Label()
        Me.txtChangeDays = New System.Windows.Forms.TextBox()
        Me.lblChangeDays = New System.Windows.Forms.Label()
        Me.lblMinPasswordExplain = New System.Windows.Forms.Label()
        Me.txtMinPassword = New System.Windows.Forms.TextBox()
        Me.lblMinPassword = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMSPPrefixSettings = New System.Windows.Forms.TextBox()
        Me.lblMSPPrefixSettings = New System.Windows.Forms.Label()
        Me.txtMSPNameSettings = New System.Windows.Forms.TextBox()
        Me.lblMSPNameSettings = New System.Windows.Forms.Label()
        Me.btn_SaveSettings = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.tabMyAccount.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.tabManageUsers.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.tabManageLocations.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.DataGridViewLocations, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.tabServiceAccount.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.tabSettings.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabMyAccount)
        Me.TabControl1.Controls.Add(Me.tabManageUsers)
        Me.TabControl1.Controls.Add(Me.tabManageLocations)
        Me.TabControl1.Controls.Add(Me.tabServiceAccount)
        Me.TabControl1.Controls.Add(Me.tabSettings)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(768, 612)
        Me.TabControl1.TabIndex = 2
        '
        'tabMyAccount
        '
        Me.tabMyAccount.Controls.Add(Me.Panel2)
        Me.tabMyAccount.Controls.Add(Me.Panel1)
        Me.tabMyAccount.Location = New System.Drawing.Point(4, 22)
        Me.tabMyAccount.Name = "tabMyAccount"
        Me.tabMyAccount.Padding = New System.Windows.Forms.Padding(3)
        Me.tabMyAccount.Size = New System.Drawing.Size(760, 586)
        Me.tabMyAccount.TabIndex = 0
        Me.tabMyAccount.Text = "My Account"
        Me.tabMyAccount.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.lblMyWarning)
        Me.Panel2.Location = New System.Drawing.Point(392, 22)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(346, 543)
        Me.Panel2.TabIndex = 21
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(114, 433)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'lblMyWarning
        '
        Me.lblMyWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMyWarning.ForeColor = System.Drawing.Color.Crimson
        Me.lblMyWarning.Location = New System.Drawing.Point(3, 215)
        Me.lblMyWarning.Name = "lblMyWarning"
        Me.lblMyWarning.Size = New System.Drawing.Size(343, 68)
        Me.lblMyWarning.TabIndex = 14
        Me.lblMyWarning.Text = "Username Does Not Exists.  Please contact your supervisor."
        Me.lblMyWarning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblMyWarning.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.btnMySavePassword)
        Me.Panel1.Controls.Add(Me.txtMyUsername)
        Me.Panel1.Controls.Add(Me.lblNewPassword)
        Me.Panel1.Controls.Add(Me.lblMyPrefix)
        Me.Panel1.Controls.Add(Me.txtNewPassword)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.txtMyPassword)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btnShowPassword)
        Me.Panel1.Location = New System.Drawing.Point(18, 22)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(346, 543)
        Me.Panel1.TabIndex = 20
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(3, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(120, 24)
        Me.Label16.TabIndex = 31
        Me.Label16.Text = "My Account"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(0, 281)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(346, 59)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "You can specify a password or leave it set to Random to have a complex password g" & _
    "enerated by the plugin.  Passwords must meet minimum length and complexity requi" & _
    "rements."
        '
        'btnMySavePassword
        '
        Me.btnMySavePassword.Location = New System.Drawing.Point(6, 404)
        Me.btnMySavePassword.Name = "btnMySavePassword"
        Me.btnMySavePassword.Size = New System.Drawing.Size(110, 23)
        Me.btnMySavePassword.TabIndex = 15
        Me.btnMySavePassword.Text = "Change Password"
        Me.btnMySavePassword.UseVisualStyleBackColor = True
        '
        'txtMyUsername
        '
        Me.txtMyUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMyUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMyUsername.Location = New System.Drawing.Point(122, 78)
        Me.txtMyUsername.Margin = New System.Windows.Forms.Padding(0, 3, 3, 3)
        Me.txtMyUsername.MaxLength = 50
        Me.txtMyUsername.Name = "txtMyUsername"
        Me.txtMyUsername.ReadOnly = True
        Me.txtMyUsername.Size = New System.Drawing.Size(159, 21)
        Me.txtMyUsername.TabIndex = 10
        '
        'lblNewPassword
        '
        Me.lblNewPassword.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblNewPassword.AutoSize = True
        Me.lblNewPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNewPassword.Location = New System.Drawing.Point(3, 361)
        Me.lblNewPassword.Name = "lblNewPassword"
        Me.lblNewPassword.Size = New System.Drawing.Size(105, 15)
        Me.lblNewPassword.TabIndex = 17
        Me.lblNewPassword.Text = "New Password:"
        '
        'lblMyPrefix
        '
        Me.lblMyPrefix.Location = New System.Drawing.Point(86, 83)
        Me.lblMyPrefix.Margin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.lblMyPrefix.Name = "lblMyPrefix"
        Me.lblMyPrefix.Size = New System.Drawing.Size(36, 13)
        Me.lblMyPrefix.TabIndex = 9
        Me.lblMyPrefix.Text = "MSP_"
        Me.lblMyPrefix.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtNewPassword
        '
        Me.txtNewPassword.Location = New System.Drawing.Point(114, 360)
        Me.txtNewPassword.MaxLength = 99
        Me.txtNewPassword.Name = "txtNewPassword"
        Me.txtNewPassword.Size = New System.Drawing.Size(126, 20)
        Me.txtNewPassword.TabIndex = 18
        Me.txtNewPassword.Text = "Random"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(3, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 15)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Username:"
        '
        'txtMyPassword
        '
        Me.txtMyPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMyPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMyPassword.Location = New System.Drawing.Point(82, 126)
        Me.txtMyPassword.MaxLength = 99
        Me.txtMyPassword.Name = "txtMyPassword"
        Me.txtMyPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtMyPassword.ReadOnly = True
        Me.txtMyPassword.Size = New System.Drawing.Size(128, 21)
        Me.txtMyPassword.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 15)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Password:"
        '
        'btnShowPassword
        '
        Me.btnShowPassword.Location = New System.Drawing.Point(6, 173)
        Me.btnShowPassword.Name = "btnShowPassword"
        Me.btnShowPassword.Size = New System.Drawing.Size(112, 23)
        Me.btnShowPassword.TabIndex = 16
        Me.btnShowPassword.Text = "Show Password"
        Me.btnShowPassword.UseVisualStyleBackColor = True
        '
        'tabManageUsers
        '
        Me.tabManageUsers.Controls.Add(Me.Panel4)
        Me.tabManageUsers.Controls.Add(Me.Panel3)
        Me.tabManageUsers.Location = New System.Drawing.Point(4, 22)
        Me.tabManageUsers.Name = "tabManageUsers"
        Me.tabManageUsers.Padding = New System.Windows.Forms.Padding(3)
        Me.tabManageUsers.Size = New System.Drawing.Size(760, 586)
        Me.tabManageUsers.TabIndex = 2
        Me.tabManageUsers.Text = "Manage Users"
        Me.tabManageUsers.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.ChangeAll)
        Me.Panel4.Controls.Add(Me.Label11)
        Me.Panel4.Controls.Add(Me.DataGridView1)
        Me.Panel4.Controls.Add(Me.btnDelete)
        Me.Panel4.Location = New System.Drawing.Point(395, 20)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(346, 543)
        Me.Panel4.TabIndex = 33
        '
        'ChangeAll
        '
        Me.ChangeAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ChangeAll.Location = New System.Drawing.Point(147, 495)
        Me.ChangeAll.Name = "ChangeAll"
        Me.ChangeAll.Size = New System.Drawing.Size(191, 23)
        Me.ChangeAll.TabIndex = 32
        Me.ChangeAll.Text = "Change All Passwords Everywhere!"
        Me.ChangeAll.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(3, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(143, 24)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Existing Users"
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.NullValue = " "
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridView1.Location = New System.Drawing.Point(7, 38)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(331, 434)
        Me.DataGridView1.TabIndex = 1
        '
        'btnDelete
        '
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.Location = New System.Drawing.Point(7, 495)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(96, 23)
        Me.btnDelete.TabIndex = 10
        Me.btnDelete.Text = "Delete Selected"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.btnAddUser)
        Me.Panel3.Controls.Add(Me.LabelPrefix)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.txtPassword)
        Me.Panel3.Controls.Add(Me.cbUserName)
        Me.Panel3.Location = New System.Drawing.Point(18, 20)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(346, 543)
        Me.Panel3.TabIndex = 32
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 38)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(331, 316)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = resources.GetString("Label9.Text")
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(3, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(111, 24)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "New Users"
        '
        'btnAddUser
        '
        Me.btnAddUser.Location = New System.Drawing.Point(7, 495)
        Me.btnAddUser.Name = "btnAddUser"
        Me.btnAddUser.Size = New System.Drawing.Size(75, 23)
        Me.btnAddUser.TabIndex = 3
        Me.btnAddUser.Text = "Add User"
        Me.btnAddUser.UseVisualStyleBackColor = True
        '
        'LabelPrefix
        '
        Me.LabelPrefix.Location = New System.Drawing.Point(86, 405)
        Me.LabelPrefix.Margin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.LabelPrefix.Name = "LabelPrefix"
        Me.LabelPrefix.Size = New System.Drawing.Size(36, 13)
        Me.LabelPrefix.TabIndex = 4
        Me.LabelPrefix.Text = "MSP_"
        Me.LabelPrefix.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 403)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 15)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Username:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 453)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Password:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(82, 452)
        Me.txtPassword.MaxLength = 99
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(173, 20)
        Me.txtPassword.TabIndex = 8
        Me.txtPassword.Text = "Random"
        '
        'cbUserName
        '
        Me.cbUserName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbUserName.FormattingEnabled = True
        Me.cbUserName.Location = New System.Drawing.Point(122, 402)
        Me.cbUserName.Name = "cbUserName"
        Me.cbUserName.Size = New System.Drawing.Size(212, 21)
        Me.cbUserName.TabIndex = 11
        '
        'tabManageLocations
        '
        Me.tabManageLocations.Controls.Add(Me.Panel6)
        Me.tabManageLocations.Controls.Add(Me.Panel5)
        Me.tabManageLocations.Location = New System.Drawing.Point(4, 22)
        Me.tabManageLocations.Name = "tabManageLocations"
        Me.tabManageLocations.Padding = New System.Windows.Forms.Padding(3)
        Me.tabManageLocations.Size = New System.Drawing.Size(760, 586)
        Me.tabManageLocations.TabIndex = 3
        Me.tabManageLocations.Text = "Manage Locations"
        Me.tabManageLocations.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.btnSaveExclusions)
        Me.Panel6.Controls.Add(Me.DataGridViewLocations)
        Me.Panel6.Location = New System.Drawing.Point(393, 22)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(346, 543)
        Me.Panel6.TabIndex = 36
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(3, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(182, 24)
        Me.Label14.TabIndex = 32
        Me.Label14.Text = "Exclude Locations"
        '
        'btnSaveExclusions
        '
        Me.btnSaveExclusions.Location = New System.Drawing.Point(16, 515)
        Me.btnSaveExclusions.Name = "btnSaveExclusions"
        Me.btnSaveExclusions.Size = New System.Drawing.Size(159, 23)
        Me.btnSaveExclusions.TabIndex = 34
        Me.btnSaveExclusions.Text = "Save Exclusions"
        Me.btnSaveExclusions.UseVisualStyleBackColor = True
        '
        'DataGridViewLocations
        '
        Me.DataGridViewLocations.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewLocations.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridViewLocations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle16.NullValue = " "
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewLocations.DefaultCellStyle = DataGridViewCellStyle16
        Me.DataGridViewLocations.Location = New System.Drawing.Point(7, 35)
        Me.DataGridViewLocations.Name = "DataGridViewLocations"
        Me.DataGridViewLocations.Size = New System.Drawing.Size(332, 455)
        Me.DataGridViewLocations.TabIndex = 20
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label15)
        Me.Panel5.Controls.Add(Me.cbxTACusers)
        Me.Panel5.Controls.Add(Me.cbxTAClocations)
        Me.Panel5.Controls.Add(Me.lblTACusers)
        Me.Panel5.Controls.Add(Me.lblTAClocations)
        Me.Panel5.Controls.Add(Me.btnAllLocationsExec)
        Me.Panel5.Controls.Add(Me.cbxTACactions)
        Me.Panel5.Controls.Add(Me.cbxTACxoverride)
        Me.Panel5.Controls.Add(Me.lblTACactions)
        Me.Panel5.Location = New System.Drawing.Point(17, 22)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(346, 543)
        Me.Panel5.TabIndex = 35
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(3, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(166, 24)
        Me.Label15.TabIndex = 33
        Me.Label15.Text = "Modify Locations"
        '
        'cbxTACusers
        '
        Me.cbxTACusers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTACusers.FormattingEnabled = True
        Me.cbxTACusers.Location = New System.Drawing.Point(72, 188)
        Me.cbxTACusers.Name = "cbxTACusers"
        Me.cbxTACusers.Size = New System.Drawing.Size(159, 21)
        Me.cbxTACusers.TabIndex = 12
        '
        'cbxTAClocations
        '
        Me.cbxTAClocations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTAClocations.FormattingEnabled = True
        Me.cbxTAClocations.Location = New System.Drawing.Point(72, 53)
        Me.cbxTAClocations.Name = "cbxTAClocations"
        Me.cbxTAClocations.Size = New System.Drawing.Size(266, 21)
        Me.cbxTAClocations.TabIndex = 13
        '
        'lblTACusers
        '
        Me.lblTACusers.AutoSize = True
        Me.lblTACusers.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTACusers.Location = New System.Drawing.Point(4, 194)
        Me.lblTACusers.Name = "lblTACusers"
        Me.lblTACusers.Size = New System.Drawing.Size(37, 15)
        Me.lblTACusers.TabIndex = 14
        Me.lblTACusers.Text = "User"
        '
        'lblTAClocations
        '
        Me.lblTAClocations.AutoSize = True
        Me.lblTAClocations.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTAClocations.Location = New System.Drawing.Point(4, 54)
        Me.lblTAClocations.Name = "lblTAClocations"
        Me.lblTAClocations.Size = New System.Drawing.Size(62, 15)
        Me.lblTAClocations.TabIndex = 15
        Me.lblTAClocations.Text = "Location"
        '
        'btnAllLocationsExec
        '
        Me.btnAllLocationsExec.Location = New System.Drawing.Point(7, 242)
        Me.btnAllLocationsExec.Name = "btnAllLocationsExec"
        Me.btnAllLocationsExec.Size = New System.Drawing.Size(159, 23)
        Me.btnAllLocationsExec.TabIndex = 19
        Me.btnAllLocationsExec.Text = "Execute Selected Action"
        Me.btnAllLocationsExec.UseVisualStyleBackColor = True
        '
        'cbxTACactions
        '
        Me.cbxTACactions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTACactions.FormattingEnabled = True
        Me.cbxTACactions.Items.AddRange(New Object() {"Select Action", "Add All Users", "Delete All Users", "Add Individual User", "Delete Individual User"})
        Me.cbxTACactions.Location = New System.Drawing.Point(72, 132)
        Me.cbxTACactions.Name = "cbxTACactions"
        Me.cbxTACactions.Size = New System.Drawing.Size(159, 21)
        Me.cbxTACactions.TabIndex = 16
        '
        'cbxTACxoverride
        '
        Me.cbxTACxoverride.AutoSize = True
        Me.cbxTACxoverride.Location = New System.Drawing.Point(72, 80)
        Me.cbxTACxoverride.Name = "cbxTACxoverride"
        Me.cbxTACxoverride.Size = New System.Drawing.Size(157, 17)
        Me.cbxTACxoverride.TabIndex = 18
        Me.cbxTACxoverride.Text = "Include Excluded Locations"
        Me.cbxTACxoverride.UseVisualStyleBackColor = True
        '
        'lblTACactions
        '
        Me.lblTACactions.AutoSize = True
        Me.lblTACactions.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTACactions.Location = New System.Drawing.Point(4, 133)
        Me.lblTACactions.Name = "lblTACactions"
        Me.lblTACactions.Size = New System.Drawing.Size(46, 15)
        Me.lblTACactions.TabIndex = 17
        Me.lblTACactions.Text = "Action"
        '
        'tabServiceAccount
        '
        Me.tabServiceAccount.Controls.Add(Me.Panel8)
        Me.tabServiceAccount.Controls.Add(Me.Panel7)
        Me.tabServiceAccount.Location = New System.Drawing.Point(4, 22)
        Me.tabServiceAccount.Name = "tabServiceAccount"
        Me.tabServiceAccount.Padding = New System.Windows.Forms.Padding(3)
        Me.tabServiceAccount.Size = New System.Drawing.Size(760, 586)
        Me.tabServiceAccount.TabIndex = 4
        Me.tabServiceAccount.Text = "Service Account"
        Me.tabServiceAccount.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.lblLocalAccountsExclude)
        Me.Panel8.Controls.Add(Me.chkLocalAccountsExclude)
        Me.Panel8.Controls.Add(Me.Label13)
        Me.Panel8.Controls.Add(Me.lblLocalAccountsFlag)
        Me.Panel8.Controls.Add(Me.lblLocalAccountsFlagExplain)
        Me.Panel8.Controls.Add(Me.btnLocalAccountsFlag)
        Me.Panel8.Controls.Add(Me.chkLocalAccountsFlag)
        Me.Panel8.Location = New System.Drawing.Point(393, 21)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(346, 543)
        Me.Panel8.TabIndex = 43
        '
        'lblLocalAccountsExclude
        '
        Me.lblLocalAccountsExclude.AutoSize = True
        Me.lblLocalAccountsExclude.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocalAccountsExclude.Location = New System.Drawing.Point(4, 202)
        Me.lblLocalAccountsExclude.Name = "lblLocalAccountsExclude"
        Me.lblLocalAccountsExclude.Size = New System.Drawing.Size(187, 15)
        Me.lblLocalAccountsExclude.TabIndex = 42
        Me.lblLocalAccountsExclude.Text = "Include Excluded Locations:"
        '
        'chkLocalAccountsExclude
        '
        Me.chkLocalAccountsExclude.AutoSize = True
        Me.chkLocalAccountsExclude.Checked = True
        Me.chkLocalAccountsExclude.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLocalAccountsExclude.Location = New System.Drawing.Point(238, 200)
        Me.chkLocalAccountsExclude.Name = "chkLocalAccountsExclude"
        Me.chkLocalAccountsExclude.Size = New System.Drawing.Size(44, 17)
        Me.chkLocalAccountsExclude.TabIndex = 43
        Me.chkLocalAccountsExclude.Text = "Yes"
        Me.chkLocalAccountsExclude.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(3, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(219, 24)
        Me.Label13.TabIndex = 41
        Me.Label13.Text = "Local Service Account"
        '
        'lblLocalAccountsFlag
        '
        Me.lblLocalAccountsFlag.AutoSize = True
        Me.lblLocalAccountsFlag.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocalAccountsFlag.Location = New System.Drawing.Point(4, 166)
        Me.lblLocalAccountsFlag.Name = "lblLocalAccountsFlag"
        Me.lblLocalAccountsFlag.Size = New System.Drawing.Size(204, 15)
        Me.lblLocalAccountsFlag.TabIndex = 35
        Me.lblLocalAccountsFlag.Text = "Create Local Service Accounts:"
        '
        'lblLocalAccountsFlagExplain
        '
        Me.lblLocalAccountsFlagExplain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocalAccountsFlagExplain.Location = New System.Drawing.Point(4, 37)
        Me.lblLocalAccountsFlagExplain.Name = "lblLocalAccountsFlagExplain"
        Me.lblLocalAccountsFlagExplain.Size = New System.Drawing.Size(339, 124)
        Me.lblLocalAccountsFlagExplain.TabIndex = 36
        Me.lblLocalAccountsFlagExplain.Text = resources.GetString("lblLocalAccountsFlagExplain.Text")
        '
        'btnLocalAccountsFlag
        '
        Me.btnLocalAccountsFlag.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnLocalAccountsFlag.Location = New System.Drawing.Point(7, 242)
        Me.btnLocalAccountsFlag.Name = "btnLocalAccountsFlag"
        Me.btnLocalAccountsFlag.Size = New System.Drawing.Size(97, 23)
        Me.btnLocalAccountsFlag.TabIndex = 38
        Me.btnLocalAccountsFlag.Text = "Save Setting"
        Me.btnLocalAccountsFlag.UseVisualStyleBackColor = True
        '
        'chkLocalAccountsFlag
        '
        Me.chkLocalAccountsFlag.AutoSize = True
        Me.chkLocalAccountsFlag.Location = New System.Drawing.Point(238, 164)
        Me.chkLocalAccountsFlag.Name = "chkLocalAccountsFlag"
        Me.chkLocalAccountsFlag.Size = New System.Drawing.Size(44, 17)
        Me.chkLocalAccountsFlag.TabIndex = 37
        Me.chkLocalAccountsFlag.Text = "Yes"
        Me.chkLocalAccountsFlag.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.btnServicePass)
        Me.Panel7.Controls.Add(Me.lblServiceAccountPass)
        Me.Panel7.Controls.Add(Me.txtServicePass)
        Me.Panel7.Controls.Add(Me.Label12)
        Me.Panel7.Controls.Add(Me.lblServiceAccount)
        Me.Panel7.Controls.Add(Me.cbxServiceAccount)
        Me.Panel7.Controls.Add(Me.lblServiceAccountPrefix)
        Me.Panel7.Controls.Add(Me.btnServiceAccount)
        Me.Panel7.Controls.Add(Me.Label5)
        Me.Panel7.Location = New System.Drawing.Point(17, 21)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(346, 543)
        Me.Panel7.TabIndex = 42
        '
        'btnServicePass
        '
        Me.btnServicePass.Location = New System.Drawing.Point(7, 431)
        Me.btnServicePass.Name = "btnServicePass"
        Me.btnServicePass.Size = New System.Drawing.Size(110, 23)
        Me.btnServicePass.TabIndex = 41
        Me.btnServicePass.Text = "Change Password"
        Me.btnServicePass.UseVisualStyleBackColor = True
        '
        'lblServiceAccountPass
        '
        Me.lblServiceAccountPass.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblServiceAccountPass.AutoSize = True
        Me.lblServiceAccountPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServiceAccountPass.Location = New System.Drawing.Point(4, 406)
        Me.lblServiceAccountPass.Name = "lblServiceAccountPass"
        Me.lblServiceAccountPass.Size = New System.Drawing.Size(105, 15)
        Me.lblServiceAccountPass.TabIndex = 42
        Me.lblServiceAccountPass.Text = "New Password:"
        '
        'txtServicePass
        '
        Me.txtServicePass.Location = New System.Drawing.Point(115, 405)
        Me.txtServicePass.MaxLength = 99
        Me.txtServicePass.Name = "txtServicePass"
        Me.txtServicePass.Size = New System.Drawing.Size(126, 20)
        Me.txtServicePass.TabIndex = 43
        Me.txtServicePass.Text = "Random"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(3, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(240, 24)
        Me.Label12.TabIndex = 40
        Me.Label12.Text = "Domain Service Account"
        '
        'lblServiceAccount
        '
        Me.lblServiceAccount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblServiceAccount.AutoSize = True
        Me.lblServiceAccount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServiceAccount.Location = New System.Drawing.Point(3, 287)
        Me.lblServiceAccount.Name = "lblServiceAccount"
        Me.lblServiceAccount.Size = New System.Drawing.Size(112, 15)
        Me.lblServiceAccount.TabIndex = 25
        Me.lblServiceAccount.Text = "Service Account:"
        '
        'cbxServiceAccount
        '
        Me.cbxServiceAccount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cbxServiceAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxServiceAccount.FormattingEnabled = True
        Me.cbxServiceAccount.Location = New System.Drawing.Point(147, 286)
        Me.cbxServiceAccount.Name = "cbxServiceAccount"
        Me.cbxServiceAccount.Size = New System.Drawing.Size(198, 21)
        Me.cbxServiceAccount.TabIndex = 26
        '
        'lblServiceAccountPrefix
        '
        Me.lblServiceAccountPrefix.Location = New System.Drawing.Point(121, 289)
        Me.lblServiceAccountPrefix.Margin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.lblServiceAccountPrefix.Name = "lblServiceAccountPrefix"
        Me.lblServiceAccountPrefix.Size = New System.Drawing.Size(75, 13)
        Me.lblServiceAccountPrefix.TabIndex = 39
        Me.lblServiceAccountPrefix.Text = "MSP_"
        Me.lblServiceAccountPrefix.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnServiceAccount
        '
        Me.btnServiceAccount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnServiceAccount.Location = New System.Drawing.Point(6, 313)
        Me.btnServiceAccount.Name = "btnServiceAccount"
        Me.btnServiceAccount.Size = New System.Drawing.Size(178, 23)
        Me.btnServiceAccount.TabIndex = 27
        Me.btnServiceAccount.Text = "Change Service Account"
        Me.btnServiceAccount.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 34)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(341, 231)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = resources.GetString("Label5.Text")
        '
        'tabSettings
        '
        Me.tabSettings.Controls.Add(Me.Label22)
        Me.tabSettings.Controls.Add(Me.txtMinLower)
        Me.tabSettings.Controls.Add(Me.Label21)
        Me.tabSettings.Controls.Add(Me.txtMinNumber)
        Me.tabSettings.Controls.Add(Me.Label19)
        Me.tabSettings.Controls.Add(Me.txtMinSpecial)
        Me.tabSettings.Controls.Add(Me.Label18)
        Me.tabSettings.Controls.Add(Me.txtMinUpper)
        Me.tabSettings.Controls.Add(Me.Label17)
        Me.tabSettings.Controls.Add(Me.btnTest)
        Me.tabSettings.Controls.Add(Me.lblVersion)
        Me.tabSettings.Controls.Add(Me.lblChangeDaysExplain)
        Me.tabSettings.Controls.Add(Me.txtChangeDays)
        Me.tabSettings.Controls.Add(Me.lblChangeDays)
        Me.tabSettings.Controls.Add(Me.lblMinPasswordExplain)
        Me.tabSettings.Controls.Add(Me.txtMinPassword)
        Me.tabSettings.Controls.Add(Me.lblMinPassword)
        Me.tabSettings.Controls.Add(Me.Label7)
        Me.tabSettings.Controls.Add(Me.Label6)
        Me.tabSettings.Controls.Add(Me.txtMSPPrefixSettings)
        Me.tabSettings.Controls.Add(Me.lblMSPPrefixSettings)
        Me.tabSettings.Controls.Add(Me.txtMSPNameSettings)
        Me.tabSettings.Controls.Add(Me.lblMSPNameSettings)
        Me.tabSettings.Controls.Add(Me.btn_SaveSettings)
        Me.tabSettings.Location = New System.Drawing.Point(4, 22)
        Me.tabSettings.Name = "tabSettings"
        Me.tabSettings.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSettings.Size = New System.Drawing.Size(760, 586)
        Me.tabSettings.TabIndex = 1
        Me.tabSettings.Text = "Settings"
        Me.tabSettings.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(389, 220)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(337, 19)
        Me.Label22.TabIndex = 40
        Me.Label22.Text = "Minimum number of Lowercase"
        '
        'txtMinLower
        '
        Me.txtMinLower.Location = New System.Drawing.Point(187, 219)
        Me.txtMinLower.MaxLength = 2
        Me.txtMinLower.Name = "txtMinLower"
        Me.txtMinLower.Size = New System.Drawing.Size(183, 20)
        Me.txtMinLower.TabIndex = 39
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(389, 246)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(337, 19)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "Minimum number of Numbers"
        '
        'txtMinNumber
        '
        Me.txtMinNumber.Location = New System.Drawing.Point(187, 245)
        Me.txtMinNumber.MaxLength = 2
        Me.txtMinNumber.Name = "txtMinNumber"
        Me.txtMinNumber.Size = New System.Drawing.Size(183, 20)
        Me.txtMinNumber.TabIndex = 37
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(389, 272)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(337, 19)
        Me.Label19.TabIndex = 34
        Me.Label19.Text = "Minimum number of Symbols"
        '
        'txtMinSpecial
        '
        Me.txtMinSpecial.Location = New System.Drawing.Point(187, 271)
        Me.txtMinSpecial.MaxLength = 2
        Me.txtMinSpecial.Name = "txtMinSpecial"
        Me.txtMinSpecial.Size = New System.Drawing.Size(183, 20)
        Me.txtMinSpecial.TabIndex = 33
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(389, 194)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(337, 19)
        Me.Label18.TabIndex = 32
        Me.Label18.Text = "Minimum number of Uppercase"
        '
        'txtMinUpper
        '
        Me.txtMinUpper.Location = New System.Drawing.Point(187, 193)
        Me.txtMinUpper.MaxLength = 2
        Me.txtMinUpper.Name = "txtMinUpper"
        Me.txtMinUpper.Size = New System.Drawing.Size(183, 20)
        Me.txtMinUpper.TabIndex = 31
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(23, 175)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(147, 15)
        Me.Label17.TabIndex = 30
        Me.Label17.Text = "Password Complexity:"
        '
        'btnTest
        '
        Me.btnTest.Location = New System.Drawing.Point(651, 420)
        Me.btnTest.Name = "btnTest"
        Me.btnTest.Size = New System.Drawing.Size(75, 23)
        Me.btnTest.TabIndex = 28
        Me.btnTest.Text = "Test Button"
        Me.btnTest.UseVisualStyleBackColor = True
        Me.btnTest.Visible = False
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Location = New System.Drawing.Point(33, 545)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(61, 13)
        Me.lblVersion.TabIndex = 27
        Me.lblVersion.Text = "ver. 2.0.0.0"
        '
        'lblChangeDaysExplain
        '
        Me.lblChangeDaysExplain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChangeDaysExplain.Location = New System.Drawing.Point(389, 329)
        Me.lblChangeDaysExplain.Name = "lblChangeDaysExplain"
        Me.lblChangeDaysExplain.Size = New System.Drawing.Size(337, 19)
        Me.lblChangeDaysExplain.TabIndex = 26
        Me.lblChangeDaysExplain.Text = "Days between automatic  password changes."
        '
        'txtChangeDays
        '
        Me.txtChangeDays.Location = New System.Drawing.Point(187, 329)
        Me.txtChangeDays.MaxLength = 2
        Me.txtChangeDays.Name = "txtChangeDays"
        Me.txtChangeDays.Size = New System.Drawing.Size(183, 20)
        Me.txtChangeDays.TabIndex = 25
        '
        'lblChangeDays
        '
        Me.lblChangeDays.AutoSize = True
        Me.lblChangeDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChangeDays.Location = New System.Drawing.Point(23, 330)
        Me.lblChangeDays.Name = "lblChangeDays"
        Me.lblChangeDays.Size = New System.Drawing.Size(158, 15)
        Me.lblChangeDays.TabIndex = 24
        Me.lblChangeDays.Text = "Auto Change Password:"
        '
        'lblMinPasswordExplain
        '
        Me.lblMinPasswordExplain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMinPasswordExplain.Location = New System.Drawing.Point(392, 128)
        Me.lblMinPasswordExplain.Name = "lblMinPasswordExplain"
        Me.lblMinPasswordExplain.Size = New System.Drawing.Size(337, 19)
        Me.lblMinPasswordExplain.TabIndex = 23
        Me.lblMinPasswordExplain.Text = "Minimum length for Passwords.  Between 10 and 99"
        '
        'txtMinPassword
        '
        Me.txtMinPassword.Location = New System.Drawing.Point(187, 127)
        Me.txtMinPassword.MaxLength = 2
        Me.txtMinPassword.Name = "txtMinPassword"
        Me.txtMinPassword.Size = New System.Drawing.Size(183, 20)
        Me.txtMinPassword.TabIndex = 22
        '
        'lblMinPassword
        '
        Me.lblMinPassword.AutoSize = True
        Me.lblMinPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMinPassword.Location = New System.Drawing.Point(23, 128)
        Me.lblMinPassword.Name = "lblMinPassword"
        Me.lblMinPassword.Size = New System.Drawing.Size(101, 15)
        Me.lblMinPassword.TabIndex = 21
        Me.lblMinPassword.Text = "Min Password:"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(393, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(336, 19)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "This is prefixed to user names in AD."
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(389, 36)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(340, 19)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "The name is used for the AD OU and user display names."
        '
        'txtMSPPrefixSettings
        '
        Me.txtMSPPrefixSettings.Location = New System.Drawing.Point(187, 79)
        Me.txtMSPPrefixSettings.MaxLength = 50
        Me.txtMSPPrefixSettings.Name = "txtMSPPrefixSettings"
        Me.txtMSPPrefixSettings.Size = New System.Drawing.Size(183, 20)
        Me.txtMSPPrefixSettings.TabIndex = 12
        '
        'lblMSPPrefixSettings
        '
        Me.lblMSPPrefixSettings.AutoSize = True
        Me.lblMSPPrefixSettings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMSPPrefixSettings.Location = New System.Drawing.Point(23, 80)
        Me.lblMSPPrefixSettings.Name = "lblMSPPrefixSettings"
        Me.lblMSPPrefixSettings.Size = New System.Drawing.Size(82, 15)
        Me.lblMSPPrefixSettings.TabIndex = 11
        Me.lblMSPPrefixSettings.Text = "MSP Prefix:"
        '
        'txtMSPNameSettings
        '
        Me.txtMSPNameSettings.Location = New System.Drawing.Point(187, 35)
        Me.txtMSPNameSettings.MaxLength = 50
        Me.txtMSPNameSettings.Name = "txtMSPNameSettings"
        Me.txtMSPNameSettings.Size = New System.Drawing.Size(183, 20)
        Me.txtMSPNameSettings.TabIndex = 10
        '
        'lblMSPNameSettings
        '
        Me.lblMSPNameSettings.AutoSize = True
        Me.lblMSPNameSettings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMSPNameSettings.Location = New System.Drawing.Point(23, 36)
        Me.lblMSPNameSettings.Name = "lblMSPNameSettings"
        Me.lblMSPNameSettings.Size = New System.Drawing.Size(83, 15)
        Me.lblMSPNameSettings.TabIndex = 9
        Me.lblMSPNameSettings.Text = "MSP Name:"
        '
        'btn_SaveSettings
        '
        Me.btn_SaveSettings.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_SaveSettings.Location = New System.Drawing.Point(26, 382)
        Me.btn_SaveSettings.Name = "btn_SaveSettings"
        Me.btn_SaveSettings.Size = New System.Drawing.Size(97, 23)
        Me.btn_SaveSettings.TabIndex = 2
        Me.btn_SaveSettings.Text = "Save Settings"
        Me.btn_SaveSettings.UseVisualStyleBackColor = True
        '
        'MSP_Accounts_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(768, 612)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "MSP_Accounts_Form"
        Me.TabControl1.ResumeLayout(False)
        Me.tabMyAccount.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.tabManageUsers.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.tabManageLocations.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.DataGridViewLocations, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.tabServiceAccount.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.tabSettings.ResumeLayout(False)
        Me.tabSettings.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabMyAccount As System.Windows.Forms.TabPage
    Friend WithEvents btnMySavePassword As System.Windows.Forms.Button
    Friend WithEvents txtNewPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblNewPassword As System.Windows.Forms.Label
    Friend WithEvents btnShowPassword As System.Windows.Forms.Button
    Friend WithEvents lblMyWarning As System.Windows.Forms.Label
    Friend WithEvents txtMyPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMyUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblMyPrefix As System.Windows.Forms.Label
    Friend WithEvents tabSettings As System.Windows.Forms.TabPage
    Friend WithEvents btn_SaveSettings As System.Windows.Forms.Button
    Friend WithEvents tabManageUsers As System.Windows.Forms.TabPage
    Friend WithEvents cbUserName As System.Windows.Forms.ComboBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelPrefix As System.Windows.Forms.Label
    Friend WithEvents btnAddUser As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents tabManageLocations As System.Windows.Forms.TabPage
    Friend WithEvents cbxTACusers As System.Windows.Forms.ComboBox
    Friend WithEvents cbxTAClocations As System.Windows.Forms.ComboBox
    Friend WithEvents lblTACusers As System.Windows.Forms.Label
    Friend WithEvents lblTACactions As System.Windows.Forms.Label
    Friend WithEvents cbxTACactions As System.Windows.Forms.ComboBox
    Friend WithEvents lblTAClocations As System.Windows.Forms.Label
    Friend WithEvents cbxTACxoverride As System.Windows.Forms.CheckBox
    Friend WithEvents btnAllLocationsExec As System.Windows.Forms.Button
    Friend WithEvents txtMSPPrefixSettings As System.Windows.Forms.TextBox
    Friend WithEvents lblMSPPrefixSettings As System.Windows.Forms.Label
    Friend WithEvents txtMSPNameSettings As System.Windows.Forms.TextBox
    Friend WithEvents lblMSPNameSettings As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblMinPasswordExplain As System.Windows.Forms.Label
    Friend WithEvents txtMinPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblMinPassword As System.Windows.Forms.Label
    Friend WithEvents lblChangeDaysExplain As System.Windows.Forms.Label
    Friend WithEvents txtChangeDays As System.Windows.Forms.TextBox
    Friend WithEvents lblChangeDays As System.Windows.Forms.Label
    Friend WithEvents tabServiceAccount As System.Windows.Forms.TabPage
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnServiceAccount As System.Windows.Forms.Button
    Friend WithEvents cbxServiceAccount As System.Windows.Forms.ComboBox
    Friend WithEvents lblServiceAccount As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents chkLocalAccountsFlag As System.Windows.Forms.CheckBox
    Friend WithEvents lblLocalAccountsFlagExplain As System.Windows.Forms.Label
    Friend WithEvents lblLocalAccountsFlag As System.Windows.Forms.Label
    Friend WithEvents btnLocalAccountsFlag As System.Windows.Forms.Button
    Friend WithEvents lblServiceAccountPrefix As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewLocations As System.Windows.Forms.DataGridView
    Friend WithEvents btnSaveExclusions As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblLocalAccountsExclude As System.Windows.Forms.Label
    Friend WithEvents chkLocalAccountsExclude As System.Windows.Forms.CheckBox
    Friend WithEvents btnTest As System.Windows.Forms.Button
    Friend WithEvents btnServicePass As System.Windows.Forms.Button
    Friend WithEvents lblServiceAccountPass As System.Windows.Forms.Label
    Friend WithEvents txtServicePass As System.Windows.Forms.TextBox
    Friend WithEvents txtMinUpper As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents ChangeAll As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtMinLower As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtMinNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtMinSpecial As System.Windows.Forms.TextBox
End Class
