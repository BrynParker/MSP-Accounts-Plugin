Imports System.Text
Imports System.IO
Imports System.Xml
Imports System.Xml.Serialization
Imports LabTech.Interfaces
Imports System.Text.RegularExpressions
Imports System.Reflection
Imports System.Windows.Forms
Imports System.Drawing

Module Globals
    Public Const mVersion As Double = 2.0
    Public Const mAuthor As String = "MrRat"
    Public Const PluginName As String = "MSP Accounts by RealTime, LLC"
    Public Const sqlPassword As String = "shinybrowncoat"
End Module
